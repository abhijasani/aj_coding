<?php

define('DB_USER',"root");
define('DB_PASSWORD', "");
define('DB_DATABASE', "aj_coding");
define('DB_SERVER', "localhost");

?>