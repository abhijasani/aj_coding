<?php
    $response = array();
    include 'db_connect.php';
	
	if(isset($_GET['p_cat']))
	{
	$id= $_GET['p_cat'];
    $db = new DB_CONNECT();
    $con = $db->connect();

    $result = mysqli_query($con,"SELECT * FROM program where p_cat='$id'") or die(mysqli_error($con));

    if(mysqli_num_rows($result) > 0) {
        $response["data"] = array();

        while($row = mysqli_fetch_array($result)) {
            $product = array();
            $product["p_id"] = $row["p_id"];
            $product["p_name"] = $row["p_name"];
            $product["p_cat"] = $row["p_cat"];
            $product["p_file"] = $row["p_file"];
			$product["p_img"] = $row["p_img"];
            

            array_push($response["data"], $product);
        }
        $response["success"] = 1;
        echo json_encode($response);
    }
    else{
        $response["success"]= 0;
        $response["message"] = "no data found";

        echo json_encode($response);
    }
	}
?>