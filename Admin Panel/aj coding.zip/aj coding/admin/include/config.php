 <?php
 
 $t = time();

        $link = mysqli_connect("localhost","root","");

        mysqli_select_db($link,"aj_coding");
		
		
		?>