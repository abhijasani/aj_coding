<?php
session_start();        

    if(! empty($_POST))
    {
        extract($_POST);
        $error = array();

        if(empty($pnm))
        {
            $error[]="please enter program name";
        }
        

        if(! empty($_FILES['image']['name']))
        {
            $ext= strtoupper(substr($_FILES['image']['name'],-4));
       
            if(!($ext==".txt" || $ext==".TXT" ))
             {
                $error[]="wrong file type";
             }
         }     
       

         if(! empty($_FILES['image1']['name']))
         {
             $ext1= strtoupper(substr($_FILES['image1']['name'],-4));
 
             if(!($ext1==".JPG" || $ext1=="JPEG" || $ext1==".PNG" || $ext1==".GIF" || $ext1==".png" ))
             {
                 $error[]="wrong image type";
             }
            
         }

        
        if(! empty($error))
        {
            $_SESSION['error']=$error; 
            header("location:product_edit.php?id=$pid");
         }
        else
        {  
           include("../include/config.php");

         if(! empty($_FILES['image']['name']))
         {  
            $img_nm = $t."_".$_FILES['image']['name'];
            $img_nm1 = $t."_".$_FILES['image1']['name'];
            move_uploaded_file($_FILES['image']['tmp_name'],"../images/program/".$img_nm);
            move_uploaded_file($_FILES['image1']['tmp_name'],"../images/program/".$img_nm1);

             $q="update program set
                p_name='$pnm',
                p_cat=$category,
                p_file='$img_nm',
                p_img='$img_nm1'
                where p_id=$pid";
         }
         else{
            $q="update program set
            p_name='$pnm',
            p_cat=$category
            where p_id=$pid";

         }


           mysqli_query($link,$q);

           $_SESSION['done']="done! succesfully product update";

           header("location:product.php");
        }
    }
    else
    {
        header("location:product.php");
    }

?>