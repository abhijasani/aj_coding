<?php
session_start();

    $ext= strtoupper(substr($_FILES['image']['name'],-4));
    $ext1= strtoupper(substr($_FILES['image1']['name'],-4));
        

    if(! empty($_POST))
    {
        extract($_POST);
        $error = array();

        if(empty($pnm))
        {
            $error[]="please enter product name";
        }

       
       

        if(empty($_FILES['image']['name']))
        {
            $error[]="please select file";
        }
        else if(!($ext==".txt" || $ext==".TXT" ))
        {
            $error[]="wrong file type";
        }

        if(empty($_FILES['image1']['name']))
        {
            $error[]="please select  images";
        }
        else if(!($ext1==".JPG" || $ext1=="JPEG" || $ext1==".PNG" || $ext1==".GIF" || $ext1==".png" ))
        {
            $error[]="wrong image type ";
        }
        
        if(! empty($error))
        {
            $_SESSION['error']=$error; 
            header("location:product.php");
         }
        else
        {
           include("../include/config.php");
            $img_nm = $t."_".$_FILES['image']['name'];
            $img_nm1 = $t."_".$_FILES['image1']['name'];
           move_uploaded_file($_FILES['image']['tmp_name'],"../images/program/".$img_nm);
           move_uploaded_file($_FILES['image1']['tmp_name'],"../images/program/".$img_nm1);


           $q="insert into program
           (p_name,p_cat,p_file,p_img)
           values
           ('$pnm',$category,'$img_nm','$img_nm1')";

           mysqli_query($link,$q);

           $_SESSION['done']="done! succesfully product add";

           header("location:product.php");
        }
    }
    else
    {
        header("location:product.php");
    }

?>