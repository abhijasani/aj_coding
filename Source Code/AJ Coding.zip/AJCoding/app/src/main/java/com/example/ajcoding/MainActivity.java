package com.example.ajcoding;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<ModelCategory> list;
    AdapterCategory adapterCategory;
    RecyclerView recyclerView;
 //   private Button btnToggleDark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView)findViewById(R.id.rec);
        recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this,2));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        list = new ArrayList<>();

        APIGetRecord();

        Switch darkmode = findViewById(R.id.customSwitch);
        darkmode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                }
                else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                }
            }
        });

    }

    private void APIGetRecord() {

        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url = "http://192.168.43.163/jsonparsing/category1.php";  //
        StringRequest sr = new StringRequest(Request.Method.GET,  url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {


                    JSONObject jsonObject1 = new JSONObject(response);

                    String name = jsonObject1.getString("success"); //1

                    if(name.equals("1")) {

                        JSONObject root = new JSONObject(response);
                        JSONArray data = root.getJSONArray("data");

                        for(int i=0;i<data.length();i++) {
                            JSONObject temp = data.getJSONObject(i);
                            ModelCategory m = new ModelCategory();


                            m.setCat_id(temp.getString("l_id"));
                            m.setCat_image(temp.getString("l_img"));
                            m.setCat_nm(temp.getString("l_name"));
                            list.add(m); // add one by one record into list

                        }  // }
                        //now set to adapter
                        adapterCategory = new AdapterCategory(MainActivity.this,list);
                        recyclerView.setAdapter(adapterCategory);
                        adapterCategory.notifyDataSetChanged();

                    }
                    else
                    {

                        Toast.makeText(getApplicationContext(),"Something went wrong", Toast.LENGTH_LONG).show();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        })
        {

        };


        Button share = (Button) findViewById(R.id.share1);

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                String body = "download this app";
                String sub = "https://abhijasani.wordpress.com/";
                i.putExtra(Intent.EXTRA_TEXT,body);
                i.putExtra(Intent.EXTRA_TEXT,sub);
                startActivity(Intent.createChooser(i,"share this app"));

            }
        });


        queue.add(sr);
        }
    }