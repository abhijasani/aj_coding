package com.example.ajcoding;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

public class program extends AppCompatActivity {
    String img,nm,file;
    TextView t1;
    ImageView i1;
    ImageView down1;
    DownloadManager downloadManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_program);

        Intent i = getIntent();
        img = i.getStringExtra("img");
        nm = i.getStringExtra("nm");
        file = i.getStringExtra("file");


        t1 = (TextView)findViewById(R.id.txt1);
        t1.setText(nm);

        i1 = (ImageView)findViewById(R.id.pro_img);

        Glide.with(program.this)
                .load("http://192.168.43.163/aj%20coding/images/program/"+img)
                .centerCrop()
                .into(i1);

        ImageView share = (ImageView)findViewById(R.id.share1);

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                String body = "download this app";
                String sub = "https://abhijasani.wordpress.com/";
                i.putExtra(Intent.EXTRA_TEXT,body);
                i.putExtra(Intent.EXTRA_TEXT,sub);
                startActivity(Intent.createChooser(i,"share this app"));
            }
        });


        down1 = (ImageView)findViewById(R.id.down1);
        down1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                downloadManager = (DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);
                Uri uri = Uri.parse("http://192.168.43.163/aj%20coding/images/program/"+file);
                Toast.makeText(getApplicationContext(),"http://192.168.43.163/aj%20coding/images/program/"+file,Toast.LENGTH_SHORT).show();

                DownloadManager.Request request = new DownloadManager.Request(uri);
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                Long reference = downloadManager.enqueue(request);
            }
        });
    }
}