package com.example.ajcoding;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adaptersubcategory extends RecyclerView.Adapter<Adaptersubcategory.Myviewholder>{

    Context context;
    List<Modelsubcategory> modelsubcategories;

    public Adaptersubcategory(Context c, List<Modelsubcategory> m)
    {
        this.context=c;
        this.modelsubcategories = m;
    }

    @NonNull
    @Override
    public Myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemview = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_sub_category,null);

        return  new Adaptersubcategory.Myviewholder(itemview);
    }

    @Override
    public void onBindViewHolder(@NonNull Myviewholder holder, int position) {

        holder.t1.setText(modelsubcategories.get(position).getP_nm());

      //  holder.t3.setText(modelsubcategories.get(position).getP_id());

        holder.li.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i  = new Intent(context, program.class);
                i.putExtra("img",modelsubcategories.get(position).getP_img());
                i.putExtra("nm",modelsubcategories.get(position).getP_nm());
                i.putExtra("file",modelsubcategories.get(position).getP_file());
                context.startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() {
        return modelsubcategories.size();
    }

    public class Myviewholder extends RecyclerView.ViewHolder{
        TextView t1;
        //TextView t3;
        LinearLayout li;
        public Myviewholder(@NonNull View itemView) {
            super(itemView);

            t1 = (TextView)itemView.findViewById(R.id.sub_text);

        //    t3 = (TextView)itemView.findViewById(R.id.sub_text2);
            li= (LinearLayout)itemView.findViewById(R.id.li_cat);
        }
    }

}

