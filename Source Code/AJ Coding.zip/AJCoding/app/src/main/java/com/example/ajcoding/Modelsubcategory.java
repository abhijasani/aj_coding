package com.example.ajcoding;

public class Modelsubcategory {

    int p_id;

    public int getP_id() {
        return p_id;
    }

    public void setP_id(int p_id) {
        this.p_id = p_id;
    }

    public String getP_nm() {
        return p_nm;
    }

    public void setP_nm(String p_nm) {
        this.p_nm = p_nm;
    }

    public String getP_file() {
        return p_file;
    }

    public void setP_file(String p_file) {
        this.p_file = p_file;
    }

    public String getP_img() {
        return p_img;
    }

    public void setP_img(String p_img) {
        this.p_img = p_img;
    }

    String p_nm,p_file,p_img;
}
