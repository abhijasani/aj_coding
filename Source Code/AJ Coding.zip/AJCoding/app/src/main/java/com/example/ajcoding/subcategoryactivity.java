package com.example.ajcoding;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class subcategoryactivity extends AppCompatActivity {

    String id;

    List<Modelsubcategory> list;
    Adaptersubcategory adaptersubcategory;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subcategoryactivity);

        Intent i = getIntent();
        id = i.getStringExtra("id");

        recyclerView = (RecyclerView)findViewById(R.id.rec);
        recyclerView.setLayoutManager(new GridLayoutManager(subcategoryactivity.this,1));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        list = new ArrayList<>();

        APIGetRecord();

    }

    private void APIGetRecord() {

        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url = "http://192.168.43.163/jsonparsing/category.php?p_cat="+id;  //
        StringRequest sr = new StringRequest(Request.Method.GET,  url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {


                    JSONObject jsonObject1 = new JSONObject(response);

                    String name = jsonObject1.getString("success"); //1

                    if(name.equals("1")) {

                        JSONObject root = new JSONObject(response);
                        JSONArray data = root.getJSONArray("data");

                        for(int i=0;i<data.length();i++) {
                            JSONObject temp = data.getJSONObject(i);
                            Modelsubcategory  m = new Modelsubcategory();


                            m.setP_id(temp.getInt("p_id"));
                            m.setP_nm(temp.getString("p_name"));
                            m.setP_file(temp.getString("p_file"));
                            m.setP_img(temp.getString("p_img"));
                            list.add(m); // add one by one record into list

                        }  // }
                        //now set to adapter
                        adaptersubcategory = new Adaptersubcategory(subcategoryactivity.this,list);
                        recyclerView.setAdapter(adaptersubcategory);
                        adaptersubcategory.notifyDataSetChanged();

                    }
                    else
                    {

                        Toast.makeText(getApplicationContext(),"Something went wrong"+id, Toast.LENGTH_LONG).show();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        })
        {

        };
        queue.add(sr);
    }
}