package com.example.ajcoding;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class AdapterCategory extends RecyclerView.Adapter<AdapterCategory.MyViewHolder>{

    Context context;
    List<ModelCategory> modelCategories;

    public AdapterCategory(Context c, List<ModelCategory> m)
    {
        this.context=c;
        this.modelCategories = m;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemview = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_category,null);

        return  new AdapterCategory.MyViewHolder(itemview);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.t.setText(modelCategories.get(position).getCat_nm());
       // holder.d.setText(modelCategories.get(position).getCat_id());


        Glide.with(context)
                .load("http://192.168.43.163/aj%20coding/images/language/"+modelCategories.get(position).getCat_image())
                .centerCrop()
                .into(holder.img);


        holder.li.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i  = new Intent(context, subcategoryactivity.class);
                i.putExtra("id",modelCategories.get(position).getCat_id());
                context.startActivity(i);
            }
        });


    }

    @Override
    public int getItemCount() {
        return modelCategories.size();
    }

    public class
    MyViewHolder extends RecyclerView.ViewHolder {

        TextView t;
        LinearLayout li;
        ImageView img;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            t = (TextView)itemView.findViewById(R.id.custom_cat_txt);
            li = (LinearLayout) itemView.findViewById(R.id.li_cat);


            img = (ImageView)itemView.findViewById(R.id.custom_cat_img);
        }
    }
}
